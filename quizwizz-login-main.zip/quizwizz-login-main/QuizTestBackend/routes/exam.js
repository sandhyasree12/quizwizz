const express=require("express")
const router=express()

// router.get("/:quizid",getQuiz)

// router.post("/submitExam/:quizid",submitExam)


module.exports=router