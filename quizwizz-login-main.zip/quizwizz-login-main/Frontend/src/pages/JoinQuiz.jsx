import React from 'react'

const JoinQuiz = () => {
  return (
    <div>JoinQuiz</div>
  )
}

export default JoinQuiz