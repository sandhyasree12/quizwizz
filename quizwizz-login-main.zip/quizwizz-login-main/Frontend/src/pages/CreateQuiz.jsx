import React,{useState} from 'react'

const createQuiz = () => {
    const [quizName, setQuizName] = useState('');
  const [quizDescription, setQuizDescription] = useState('');
  
  
  
  
  return (
    <div>createQuiz</div>
  )
}

export default createQuiz