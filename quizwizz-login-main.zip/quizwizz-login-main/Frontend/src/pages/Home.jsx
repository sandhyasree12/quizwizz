import React from 'react'
import Navbar from '../components/Navbar'
import Buttonset from '../components/Buttonset'
function Home() {
  return (
    <>
    <Navbar/>
    <Buttonset/>
    
    </>
  )
}

export default Home