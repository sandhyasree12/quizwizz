import React from 'react'

const profile = () => {
  return (
    <div>profile</div>
    
  )
}

export default profile