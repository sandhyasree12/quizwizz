import React from 'react'

const CreateQuestion = ({question,set}) => {
  return (
    
  )
}

export default CreateQuestion